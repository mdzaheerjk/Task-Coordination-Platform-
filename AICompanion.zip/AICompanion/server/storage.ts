import { 
  users, tasks, projects, projectMembers, badges, userBadges,
  subscriptionPlans, userSubscriptions,
  type User, type Task, type Project, type ProjectMember, 
  type Badge, type UserBadge, type SubscriptionPlan, type UserSubscription,
  type InsertUser, type InsertTask, type InsertProject, type InsertProjectMember,
  type InsertBadge, type InsertUserBadge, type InsertSubscriptionPlan, type InsertUserSubscription
} from "@shared/schema";

// Interface for storage operations
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPoints(userId: number, points: number): Promise<User | undefined>;
  getLeaderboard(limit?: number): Promise<User[]>;
  
  // Project methods
  createProject(project: InsertProject): Promise<Project>;
  getProject(id: number): Promise<Project | undefined>;
  getProjectsByUserId(userId: number): Promise<Project[]>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined>;
  
  // Project member methods
  addProjectMember(member: InsertProjectMember): Promise<ProjectMember>;
  getProjectMembers(projectId: number): Promise<ProjectMember[]>;
  removeProjectMember(projectId: number, userId: number): Promise<boolean>;
  
  // Task methods
  createTask(task: InsertTask): Promise<Task>;
  getTask(id: number): Promise<Task | undefined>;
  getTasksByProjectId(projectId: number): Promise<Task[]>;
  getTasksByAssigneeId(assigneeId: number): Promise<Task[]>;
  getRecentTasks(limit?: number): Promise<Task[]>;
  updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;
  completeTask(id: number): Promise<Task | undefined>;
  
  // Badge methods
  createBadge(badge: InsertBadge): Promise<Badge>;
  getBadges(): Promise<Badge[]>;
  
  // User badge methods
  awardBadgeToUser(userBadge: InsertUserBadge): Promise<UserBadge>;
  getUserBadges(userId: number): Promise<Badge[]>;
  checkAndAwardBadges(userId: number): Promise<Badge[]>;
  
  // Subscription methods
  createSubscriptionPlan(plan: InsertSubscriptionPlan): Promise<SubscriptionPlan>;
  getSubscriptionPlans(): Promise<SubscriptionPlan[]>;
  getUserSubscription(userId: number): Promise<UserSubscription | undefined>;
  createUserSubscription(subscription: InsertUserSubscription): Promise<UserSubscription>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private tasks: Map<number, Task>;
  private projects: Map<number, Project>;
  private projectMembers: Map<number, ProjectMember>;
  private badges: Map<number, Badge>;
  private userBadges: Map<number, UserBadge>;
  private subscriptionPlans: Map<number, SubscriptionPlan>;
  private userSubscriptions: Map<number, UserSubscription>;
  
  private userCurrentId: number;
  private taskCurrentId: number;
  private projectCurrentId: number;
  private memberCurrentId: number;
  private badgeCurrentId: number;
  private userBadgeCurrentId: number;
  private planCurrentId: number;
  private subscriptionCurrentId: number;
  
  constructor() {
    this.users = new Map();
    this.tasks = new Map();
    this.projects = new Map();
    this.projectMembers = new Map();
    this.badges = new Map();
    this.userBadges = new Map();
    this.subscriptionPlans = new Map();
    this.userSubscriptions = new Map();
    
    this.userCurrentId = 1;
    this.taskCurrentId = 1;
    this.projectCurrentId = 1;
    this.memberCurrentId = 1;
    this.badgeCurrentId = 1;
    this.userBadgeCurrentId = 1;
    this.planCurrentId = 1;
    this.subscriptionCurrentId = 1;
    
    // Initialize with some default data
    this.initializeDefaultData();
  }
  
  private initializeDefaultData() {
    // Create default subscription plans
    this.createSubscriptionPlan({
      name: "Free Plan",
      price: 0,
      duration: 36500, // ~100 years (effectively forever)
      features: ["Up to 3 projects", "Basic task management", "2 team members", "Basic calendar view"],
      isActive: true
    });
    
    this.createSubscriptionPlan({
      name: "Pro Plan",
      price: 69900, // ₹699
      duration: 180, // 6 months
      features: ["Unlimited projects", "Advanced task management", "Up to 10 team members", "Advanced calendar & reports", "Ad-free experience", "Full gamification system"],
      isActive: true
    });
    
    // Create default badges
    this.createBadge({
      name: "Task Master",
      description: "Complete 10 tasks",
      icon: "award",
      pointsRequired: 100
    });
    
    this.createBadge({
      name: "Quick Solver",
      description: "Complete 5 tasks before their deadline",
      icon: "bolt",
      pointsRequired: 150
    });
    
    this.createBadge({
      name: "On Time",
      description: "Complete 3 tasks on the same day they were assigned",
      icon: "calendar-check",
      pointsRequired: 200
    });
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const createdAt = new Date();
    const user: User = { ...insertUser, id, createdAt, points: 0 };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserPoints(userId: number, points: number): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      points: user.points + points
    };
    
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async getLeaderboard(limit: number = 10): Promise<User[]> {
    return Array.from(this.users.values())
      .sort((a, b) => b.points - a.points)
      .slice(0, limit);
  }
  
  // Project methods
  async createProject(project: InsertProject): Promise<Project> {
    const id = this.projectCurrentId++;
    const createdAt = new Date();
    const newProject: Project = { ...project, id, createdAt };
    this.projects.set(id, newProject);
    return newProject;
  }
  
  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }
  
  async getProjectsByUserId(userId: number): Promise<Project[]> {
    const userProjects = Array.from(this.projects.values())
      .filter(project => project.ownerId === userId);
    
    const memberProjects = Array.from(this.projectMembers.values())
      .filter(member => member.userId === userId)
      .map(member => this.projects.get(member.projectId))
      .filter((project): project is Project => project !== undefined);
    
    // Combine and remove duplicates
    return [...new Map([...userProjects, ...memberProjects].map(
      project => [project.id, project]
    )).values()];
  }
  
  async updateProject(id: number, project: Partial<InsertProject>): Promise<Project | undefined> {
    const existingProject = await this.getProject(id);
    if (!existingProject) return undefined;
    
    const updatedProject: Project = {
      ...existingProject,
      ...project
    };
    
    this.projects.set(id, updatedProject);
    return updatedProject;
  }
  
  // Project member methods
  async addProjectMember(member: InsertProjectMember): Promise<ProjectMember> {
    const id = this.memberCurrentId++;
    const newMember: ProjectMember = { ...member, id };
    this.projectMembers.set(id, newMember);
    return newMember;
  }
  
  async getProjectMembers(projectId: number): Promise<ProjectMember[]> {
    return Array.from(this.projectMembers.values())
      .filter(member => member.projectId === projectId);
  }
  
  async removeProjectMember(projectId: number, userId: number): Promise<boolean> {
    const memberEntries = Array.from(this.projectMembers.entries())
      .find(([_, member]) => 
        member.projectId === projectId && member.userId === userId);
    
    if (!memberEntries) return false;
    
    return this.projectMembers.delete(memberEntries[0]);
  }
  
  // Task methods
  async createTask(task: InsertTask): Promise<Task> {
    const id = this.taskCurrentId++;
    const createdAt = new Date();
    const newTask: Task = { 
      ...task, 
      id, 
      createdAt,
      completedAt: null
    };
    this.tasks.set(id, newTask);
    return newTask;
  }
  
  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }
  
  async getTasksByProjectId(projectId: number): Promise<Task[]> {
    return Array.from(this.tasks.values())
      .filter(task => task.projectId === projectId);
  }
  
  async getTasksByAssigneeId(assigneeId: number): Promise<Task[]> {
    return Array.from(this.tasks.values())
      .filter(task => task.assigneeId === assigneeId);
  }
  
  async getRecentTasks(limit: number = 10): Promise<Task[]> {
    return Array.from(this.tasks.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }
  
  async updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined> {
    const existingTask = await this.getTask(id);
    if (!existingTask) return undefined;
    
    const updatedTask: Task = {
      ...existingTask,
      ...task
    };
    
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }
  
  async deleteTask(id: number): Promise<boolean> {
    return this.tasks.delete(id);
  }
  
  async completeTask(id: number): Promise<Task | undefined> {
    const task = await this.getTask(id);
    if (!task) return undefined;
    
    const completedTask: Task = {
      ...task,
      status: "completed",
      completedAt: new Date()
    };
    
    this.tasks.set(id, completedTask);
    
    // Award points to the assignee
    if (task.assigneeId) {
      await this.updateUserPoints(task.assigneeId, 10);
      await this.checkAndAwardBadges(task.assigneeId);
    }
    
    return completedTask;
  }
  
  // Badge methods
  async createBadge(badge: InsertBadge): Promise<Badge> {
    const id = this.badgeCurrentId++;
    const newBadge: Badge = { ...badge, id };
    this.badges.set(id, newBadge);
    return newBadge;
  }
  
  async getBadges(): Promise<Badge[]> {
    return Array.from(this.badges.values());
  }
  
  // User badge methods
  async awardBadgeToUser(userBadge: InsertUserBadge): Promise<UserBadge> {
    const id = this.userBadgeCurrentId++;
    const earnedAt = new Date();
    const newUserBadge: UserBadge = { ...userBadge, id, earnedAt };
    this.userBadges.set(id, newUserBadge);
    return newUserBadge;
  }
  
  async getUserBadges(userId: number): Promise<Badge[]> {
    const userBadgeIds = Array.from(this.userBadges.values())
      .filter(ub => ub.userId === userId)
      .map(ub => ub.badgeId);
    
    return Array.from(this.badges.values())
      .filter(badge => userBadgeIds.includes(badge.id));
  }
  
  async checkAndAwardBadges(userId: number): Promise<Badge[]> {
    const user = await this.getUser(userId);
    if (!user) return [];
    
    const userBadgeIds = (await this.getUserBadges(userId)).map(b => b.id);
    const allBadges = await this.getBadges();
    const newBadges: Badge[] = [];
    
    // Find badges the user qualifies for but doesn't have yet
    for (const badge of allBadges) {
      if (userBadgeIds.includes(badge.id)) continue;
      
      if (user.points >= badge.pointsRequired) {
        await this.awardBadgeToUser({
          userId,
          badgeId: badge.id
        });
        newBadges.push(badge);
      }
    }
    
    return newBadges;
  }
  
  // Subscription methods
  async createSubscriptionPlan(plan: InsertSubscriptionPlan): Promise<SubscriptionPlan> {
    const id = this.planCurrentId++;
    const newPlan: SubscriptionPlan = { ...plan, id };
    this.subscriptionPlans.set(id, newPlan);
    return newPlan;
  }
  
  async getSubscriptionPlans(): Promise<SubscriptionPlan[]> {
    return Array.from(this.subscriptionPlans.values())
      .filter(plan => plan.isActive);
  }
  
  async getUserSubscription(userId: number): Promise<UserSubscription | undefined> {
    return Array.from(this.userSubscriptions.values())
      .find(sub => sub.userId === userId && sub.isActive);
  }
  
  async createUserSubscription(subscription: InsertUserSubscription): Promise<UserSubscription> {
    const id = this.subscriptionCurrentId++;
    const newSubscription: UserSubscription = { ...subscription, id };
    
    // Deactivate any existing active subscriptions for this user
    for (const [existingId, existingSub] of this.userSubscriptions.entries()) {
      if (existingSub.userId === subscription.userId && existingSub.isActive) {
        this.userSubscriptions.set(existingId, {
          ...existingSub,
          isActive: false
        });
      }
    }
    
    this.userSubscriptions.set(id, newSubscription);
    return newSubscription;
  }
}

export const storage = new MemStorage();
