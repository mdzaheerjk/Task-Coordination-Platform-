import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getInitials, calculateTaskProgress } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, Users, Calendar, ClipboardList, MoreHorizontal } from "lucide-react";

// Project interface
interface Project {
  id: number;
  name: string;
  description: string;
  ownerId: number;
  createdAt: string;
}

// Enhanced project with tasks and members
interface EnhancedProject extends Project {
  tasks: {
    total: number;
    completed: number;
  };
  members: {
    id: number;
    fullName: string;
    avatarUrl?: string;
  }[];
}

// New project form component
const NewProjectForm = ({ onClose }: { onClose: () => void }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) {
      toast({
        title: "Error",
        description: "Project name is required",
        variant: "destructive"
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Using direct fetch to avoid potential issues with apiRequest
      const response = await fetch('/api/projects', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name,
          description: description || ""
        })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to create project");
      }
      
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      toast({
        title: "Success",
        description: "Project created successfully",
      });
      onClose();
    } catch (error) {
      console.error("Error creating project:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create project",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Create New Project</CardTitle>
        </CardHeader>
        <CardContent>
          <form className="space-y-4" onSubmit={handleSubmit}>
            <div className="space-y-2">
              <label htmlFor="project-name" className="text-sm font-medium">
                Project Name
              </label>
              <input
                id="project-name"
                type="text"
                className="w-full p-2 border rounded-md"
                placeholder="Enter project name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="project-description" className="text-sm font-medium">
                Description
              </label>
              <textarea
                id="project-description"
                rows={3}
                className="w-full p-2 border rounded-md"
                placeholder="Enter project description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>
            <div className="flex justify-end space-x-2 mt-4">
              <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Creating..." : "Create Project"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

const Projects = () => {
  const [showNewProjectForm, setShowNewProjectForm] = useState(false);
  
  // Fetch projects
  const { data: projects = [], isLoading } = useQuery<EnhancedProject[]>({
    queryKey: ['/api/projects'],
    select: (data) => {
      // In a real implementation, this data transformation would happen on the server
      return data.map(project => ({
        ...project,
        tasks: {
          total: Math.floor(Math.random() * 30) + 5,
          completed: Math.floor(Math.random() * 20)
        },
        members: [
          { id: 1, fullName: "Anil Rao" },
          { id: 2, fullName: "Priya Sharma" },
          { id: 3, fullName: "Mohd Zaheeruddin" }
        ].slice(0, Math.floor(Math.random() * 3) + 1)
      }));
    }
  });
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-2xl font-bold text-gray-900 font-roboto">Projects</h2>
        <div className="mt-3 sm:mt-0">
          <Button onClick={() => setShowNewProjectForm(true)}>
            <Plus className="mr-2 h-4 w-4" /> New Project
          </Button>
        </div>
      </div>
      
      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Projects</TabsTrigger>
          <TabsTrigger value="active">Active</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
          <TabsTrigger value="archived">Archived</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-6">
          {isLoading ? (
            <div className="text-center py-8">Loading projects...</div>
          ) : projects.length === 0 ? (
            <div className="text-center py-8">
              <ClipboardList className="h-12 w-12 mx-auto mb-3 text-gray-400" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No projects found</h3>
              <p className="text-gray-500 mb-4">Get started by creating a new project.</p>
              <Button onClick={() => setShowNewProjectForm(true)}>
                <Plus className="mr-2 h-4 w-4" /> Create Project
              </Button>
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {projects.map((project) => {
                const progress = calculateTaskProgress(project.tasks.completed, project.tasks.total);
                
                return (
                  <Link key={project.id} href={`/projects/${project.id}`} className="block">
                    <Card className="h-full hover:shadow-md transition-shadow">
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg">{project.name}</CardTitle>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                        <p className="text-sm text-gray-500 mt-1 line-clamp-2">
                          {project.description || "No description provided"}
                        </p>
                      </CardHeader>
                      
                      <CardContent>
                        <div className="space-y-4">
                          <div>
                            <div className="flex justify-between text-sm mb-1">
                              <span>Progress</span>
                              <span>{progress}%</span>
                            </div>
                            <Progress value={progress} className="h-2" />
                          </div>
                          
                          <div className="flex items-center gap-2">
                            <ClipboardList className="h-4 w-4 text-gray-500" />
                            <span className="text-sm">
                              {project.tasks.completed} / {project.tasks.total} tasks
                            </span>
                          </div>
                          
                          <div className="flex justify-between">
                            <div className="flex -space-x-2">
                              {project.members.map((member) => (
                                <Avatar
                                  key={member.id}
                                  className="h-7 w-7 border-2 border-white"
                                >
                                  <AvatarImage
                                    src={member.avatarUrl}
                                    alt={member.fullName}
                                  />
                                  <AvatarFallback>
                                    {getInitials(member.fullName)}
                                  </AvatarFallback>
                                </Avatar>
                              ))}
                              {project.members.length === 0 && (
                                <div className="h-7 w-7 rounded-full bg-gray-200 flex items-center justify-center border-2 border-white">
                                  <Users className="h-3 w-3 text-gray-500" />
                                </div>
                              )}
                            </div>
                            
                            <Badge variant="outline" className="whitespace-nowrap">
                              <Calendar className="h-3 w-3 mr-1" />
                              Due in 5 days
                            </Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="active">
          <div className="text-center py-8 text-gray-500">
            Active projects will be shown here
          </div>
        </TabsContent>
        
        <TabsContent value="completed">
          <div className="text-center py-8 text-gray-500">
            Completed projects will be shown here
          </div>
        </TabsContent>
        
        <TabsContent value="archived">
          <div className="text-center py-8 text-gray-500">
            Archived projects will be shown here
          </div>
        </TabsContent>
      </Tabs>
      
      {/* New Project Form Dialog */}
      {showNewProjectForm && <NewProjectForm onClose={() => setShowNewProjectForm(false)} />}
    </div>
  );
};

export default Projects;