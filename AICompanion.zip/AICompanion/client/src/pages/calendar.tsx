import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import TaskForm from "@/components/task/TaskForm";
import { Plus, ChevronLeft, ChevronRight } from "lucide-react";
import { getEventColorClass } from "@/lib/utils";

// Task interface from API
interface Task {
  id: number;
  title: string;
  status: string;
  priority: string;
  projectId: number;
  assigneeId: number | null;
  startDate: string;
  endDate: string;
}

// Project interface
interface Project {
  id: number;
  name: string;
}

// Event interface for FullCalendar
interface CalendarEvent {
  id: string;
  title: string;
  start: string;
  end: string;
  className: string;
  extendedProps: {
    taskId: number;
    status: string;
    priority: string;
  };
}

const Calendar = () => {
  const [currentView, setCurrentView] = useState<"dayGridMonth" | "timeGridWeek" | "timeGridDay">("dayGridMonth");
  const [selectedProject, setSelectedProject] = useState<string>("all");
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  
  // Fetch tasks
  const { data: tasks = [], isLoading: isLoadingTasks } = useQuery<Task[]>({
    queryKey: ['/api/tasks/recent', { limit: 100 }],
  });
  
  // Fetch projects
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
  });
  
  // Convert tasks to calendar events
  const events: CalendarEvent[] = tasks
    .filter(task => selectedProject === "all" || task.projectId.toString() === selectedProject)
    .map(task => ({
      id: `task-${task.id}`,
      title: task.title,
      start: task.startDate,
      end: task.endDate,
      className: getEventColorClass(task.priority),
      extendedProps: {
        taskId: task.id,
        status: task.status,
        priority: task.priority
      }
    }));
  
  // Handle date click to create new task
  const handleDateClick = (info: any) => {
    setSelectedDate(info.date);
    setShowTaskForm(true);
  };
  
  // Handle event click to edit task
  const handleEventClick = (info: any) => {
    const taskId = info.event.extendedProps.taskId;
    // In a full implementation, navigate to task edit or show task details
    console.log("Clicked on task ID:", taskId);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-2xl font-bold text-gray-900 font-roboto">Calendar</h2>
        <div className="mt-3 sm:mt-0 flex space-x-2">
          <Button onClick={() => setShowTaskForm(true)}>
            <Plus className="mr-2 h-4 w-4" /> New Task
          </Button>
          <Select 
            value={currentView}
            onValueChange={(value: any) => setCurrentView(value)}
          >
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="View" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="dayGridMonth">Month</SelectItem>
              <SelectItem value="timeGridWeek">Week</SelectItem>
              <SelectItem value="timeGridDay">Day</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <Card className="shadow overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <h3 className="text-lg font-medium leading-6 text-gray-900 font-roboto">
              {new Date().toLocaleString('default', { month: 'long', year: 'numeric' })}
            </h3>
            <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              Today
            </Button>
            <Select 
              value={selectedProject}
              onValueChange={setSelectedProject}
            >
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="All Projects" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Projects</SelectItem>
                {projects.map(project => (
                  <SelectItem key={project.id} value={project.id.toString()}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="p-4">
          {isLoadingTasks ? (
            <div className="h-[600px] flex items-center justify-center">
              <p className="text-gray-500">Loading calendar...</p>
            </div>
          ) : (
            <FullCalendar
              plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
              initialView={currentView}
              headerToolbar={false}
              events={events}
              height="auto"
              aspectRatio={1.5}
              dateClick={handleDateClick}
              eventClick={handleEventClick}
              eventTimeFormat={{
                hour: '2-digit',
                minute: '2-digit',
                meridiem: 'short'
              }}
              editable={true}
              selectable={true}
            />
          )}
        </div>
      </Card>
      
      {showTaskForm && (
        <TaskForm
          initialDate={selectedDate}
          onClose={() => setShowTaskForm(false)}
        />
      )}
    </div>
  );
};

export default Calendar;
