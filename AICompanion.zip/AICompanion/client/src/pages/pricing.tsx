import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'wouter';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { CheckCircle, XCircle, CreditCard, Crown } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

// Subscription plan interface
interface SubscriptionPlan {
  id: number;
  name: string;
  price: number;
  duration: number;
  features: string[];
  isActive: boolean;
}

// User subscription interface
interface UserSubscription {
  id: number;
  userId: number;
  planId: number;
  startDate: string;
  endDate: string;
  isActive: boolean;
  plan?: SubscriptionPlan;
}

// Payment modal component
const PaymentModal = ({ 
  plan, 
  onClose, 
  onSuccess 
}: { 
  plan: SubscriptionPlan; 
  onClose: () => void;
  onSuccess: () => void;
}) => {
  const [processing, setProcessing] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Subscribe mutation
  const subscription = useMutation({
    mutationFn: () => apiRequest('POST', '/api/subscriptions', { planId: plan.id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: 'Subscription successful',
        description: `You've successfully subscribed to the ${plan.name}!`
      });
      onSuccess();
    },
    onError: (error) => {
      toast({
        title: 'Subscription failed',
        description: error instanceof Error ? error.message : 'An error occurred while processing your subscription',
        variant: 'destructive'
      });
    }
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      subscription.mutate();
    }, 1500);
  };
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-md overflow-hidden">
        <div className="bg-primary px-6 py-4">
          <h3 className="text-lg font-bold text-white flex items-center">
            <CreditCard className="mr-2 h-5 w-5" /> 
            Payment Information
          </h3>
        </div>
        
        <CardContent className="p-6">
          <div className="mb-6">
            <h4 className="text-lg font-medium mb-2">Order Summary</h4>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex justify-between mb-2">
                <span>{plan.name}</span>
                <span>₹{(plan.price / 100).toFixed(2)}</span>
              </div>
              <div className="text-sm text-gray-500 mb-4">
                {plan.duration} days subscription
              </div>
              <div className="border-t pt-2 font-medium flex justify-between">
                <span>Total</span>
                <span>₹{(plan.price / 100).toFixed(2)}</span>
              </div>
            </div>
          </div>
          
          <form onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Card Number</label>
                <input 
                  type="text" 
                  placeholder="1234 5678 9012 3456" 
                  className="w-full p-2 border rounded-md" 
                  maxLength={19}
                  disabled={processing}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Expiry Date</label>
                  <input 
                    type="text" 
                    placeholder="MM/YY" 
                    className="w-full p-2 border rounded-md"
                    disabled={processing}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">CVV</label>
                  <input 
                    type="text" 
                    placeholder="123" 
                    className="w-full p-2 border rounded-md"
                    maxLength={3}
                    disabled={processing}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Name on Card</label>
                <input 
                  type="text" 
                  placeholder="John Doe" 
                  className="w-full p-2 border rounded-md"
                  disabled={processing}
                />
              </div>
            </div>
            
            <div className="mt-6 flex justify-end space-x-3">
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose}
                disabled={processing || subscription.isPending}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="bg-primary"
                disabled={processing || subscription.isPending}
              >
                {processing || subscription.isPending ? 'Processing...' : 'Pay ₹' + (plan.price / 100).toFixed(2)}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

const Pricing = () => {
  const { user, isAuthenticated } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);
  const { toast } = useToast();

  // Fetch subscription plans
  const { data: plans = [] } = useQuery<SubscriptionPlan[]>({
    queryKey: ['/api/subscription-plans'],
  });

  // Fetch user's current subscription if authenticated
  const { data: userSubscription } = useQuery<UserSubscription>({
    queryKey: ['/api/users', user?.id, 'subscription'],
    enabled: isAuthenticated && !!user?.id,
  });

  const handleSelectPlan = (plan: SubscriptionPlan) => {
    if (!isAuthenticated) {
      toast({
        title: 'Authentication required',
        description: 'Please sign in to subscribe to a plan',
      });
      return;
    }
    
    setSelectedPlan(plan);
  };

  const isPlanActive = (planId: number) => {
    return userSubscription?.planId === planId && userSubscription?.isActive;
  };

  return (
    <div className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-gray-900 font-roboto">Choose Your Plan</h2>
        <p className="mt-4 text-xl text-gray-600 max-w-3xl mx-auto">
          Get the right features for your team with our flexible pricing options
        </p>
      </div>
      
      <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
        {/* Free Plan */}
        {plans.length > 0 && plans.map((plan) => (
          <Card 
            key={plan.id}
            className={`overflow-hidden border-2 ${
              plan.name === 'Pro Plan' ? 'border-primary' : 'border-gray-200'
            }`}
          >
            <div className="px-6 py-8">
              <h3 className="text-2xl font-bold text-gray-900 font-roboto">{plan.name}</h3>
              <div className="mt-4 flex items-baseline">
                <span className="text-5xl font-extrabold tracking-tight text-gray-900">
                  ₹{(plan.price / 100).toFixed(0)}
                </span>
                <span className="ml-1 text-xl font-medium text-gray-500">
                  {plan.price === 0 ? '/forever' : '/6 months'}
                </span>
              </div>
              <p className="mt-5 text-lg text-gray-500">
                {plan.name === 'Free Plan' 
                  ? 'Perfect for individuals and small teams getting started with task management.'
                  : 'For growing teams that need more features and flexibility.'}
              </p>
            </div>
            
            <div className="px-6 py-8 bg-gray-50 sm:p-10 sm:py-6">
              <ul className="space-y-4">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-accent flex-shrink-0" />
                    <p className="ml-3 text-base text-gray-700">{feature}</p>
                  </li>
                ))}
                
                {plan.name === 'Free Plan' && (
                  <>
                    <li className="flex items-start text-gray-500">
                      <XCircle className="h-5 w-5 flex-shrink-0" />
                      <p className="ml-3 text-base">Ad-free experience</p>
                    </li>
                    <li className="flex items-start text-gray-500">
                      <XCircle className="h-5 w-5 flex-shrink-0" />
                      <p className="ml-3 text-base">Advanced gamification</p>
                    </li>
                  </>
                )}
              </ul>
              
              <div className="mt-8">
                <div className="rounded-md shadow">
                  {isPlanActive(plan.id) ? (
                    <Button className="w-full" disabled>
                      Current Plan
                    </Button>
                  ) : (
                    <Button
                      className={`w-full ${plan.name === 'Pro Plan' ? 'bg-secondary hover:bg-secondary/90' : ''}`}
                      onClick={() => handleSelectPlan(plan)}
                    >
                      {plan.price === 0 ? 'Get Started' : 'Upgrade Now'}
                    </Button>
                  )}
                </div>
              </div>
            </div>
            
            {plan.name === 'Free Plan' ? (
              <div className="px-6 py-4 bg-gray-100">
                <p className="text-xs text-gray-600 text-center">Includes personalized ads to support our service</p>
              </div>
            ) : (
              <div className="px-6 py-4 bg-primary-light">
                <p className="text-xs text-primary text-center flex items-center justify-center">
                  <Crown className="h-3 w-3 mr-1" /> Most popular choice for service providers
                </p>
              </div>
            )}
          </Card>
        ))}
        
        {plans.length === 0 && (
          <div className="col-span-2 text-center py-16">
            <p>Loading pricing plans...</p>
          </div>
        )}
      </div>
      
      <div className="mt-12 text-center">
        <p className="text-base text-gray-600">
          Need a custom enterprise plan? <a href="#contact" className="text-primary font-medium">Contact our sales team</a>
        </p>
      </div>
      
      {selectedPlan && (
        <PaymentModal 
          plan={selectedPlan} 
          onClose={() => setSelectedPlan(null)}
          onSuccess={() => setSelectedPlan(null)}
        />
      )}
    </div>
  );
};

export default Pricing;
