import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import StatCard from "@/components/dashboard/StatCard";
import Leaderboard from "@/components/dashboard/Leaderboard";
import BadgeGrid from "@/components/dashboard/BadgeGrid";
import MiniCalendar from "@/components/dashboard/MiniCalendar";
import TaskItem from "@/components/task/TaskItem";
import { 
  ClipboardList, CheckCircle, Clock, Users, 
  Plus, Filter 
} from "lucide-react";

// Task interface
interface Task {
  id: number;
  title: string;
  description: string;
  status: "pending" | "in_progress" | "completed" | "delayed";
  priority: "low" | "medium" | "high";
  projectId: number;
  assigneeId: number | null;
  startDate: string;
  endDate: string;
  completedAt: string | null;
}

// Enhanced task with project and assignee info
interface EnhancedTask extends Task {
  project: {
    id: number;
    name: string;
  };
  assignee?: {
    id: number;
    fullName: string;
    avatarUrl?: string;
  };
}

// Stats interface
interface Stats {
  totalTasks: number;
  completedTasks: number;
  pendingTasks: number;
  activeClients: number;
}

const Dashboard = () => {
  // Fetch recent tasks
  const { data: tasks = [], isLoading: isLoadingTasks } = useQuery<EnhancedTask[]>({
    queryKey: ['/api/tasks/recent'],
  });

  // Fetch stats - in a real app this would be a separate endpoint
  const { data: stats, isLoading: isLoadingStats } = useQuery<Stats>({
    queryKey: ['/api/dashboard/stats'],
    queryFn: async () => {
      // This would be a real API call, but for now we'll calculate from tasks
      const completedCount = tasks.filter(t => t.status === 'completed').length;
      return {
        totalTasks: tasks.length,
        completedTasks: completedCount,
        pendingTasks: tasks.length - completedCount,
        activeClients: new Set(tasks.map(t => t.projectId)).size,
      };
    },
    enabled: tasks.length > 0,
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-2xl font-bold text-gray-900 font-roboto">Dashboard</h2>
        <div className="mt-3 sm:mt-0 flex space-x-2">
          <Link href="/projects/new">
            <Button className="inline-flex items-center">
              <Plus className="mr-2 h-4 w-4" /> New Project
            </Button>
          </Link>
          <Button variant="outline" className="inline-flex items-center">
            <Filter className="mr-2 h-4 w-4" /> Filter
          </Button>
        </div>
      </div>
      
      {/* Stats overview */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Tasks"
          value={stats?.totalTasks || 0}
          icon={<ClipboardList className="h-5 w-5 text-primary" />}
          change={{ value: "12%", trend: "up" }}
          footerLink={{ label: "View all", href: "/tasks" }}
          iconClassName="bg-primary-light"
        />
        
        <StatCard
          title="Completed"
          value={stats?.completedTasks || 0}
          icon={<CheckCircle className="h-5 w-5 text-secondary" />}
          change={{ value: "8%", trend: "up" }}
          footerLink={{ label: "View details", href: "/tasks?status=completed" }}
          iconClassName="bg-secondary-light"
        />
        
        <StatCard
          title="Pending"
          value={stats?.pendingTasks || 0}
          icon={<Clock className="h-5 w-5 text-yellow-600" />}
          change={{ value: "3%", trend: "down" }}
          footerLink={{ label: "View pending", href: "/tasks?status=pending" }}
          iconClassName="bg-yellow-100"
        />
        
        <StatCard
          title="Active Clients"
          value={stats?.activeClients || 0}
          icon={<Users className="h-5 w-5 text-accent" />}
          change={{ value: "2", trend: "up" }}
          footerLink={{ label: "View clients", href: "/clients" }}
          iconClassName="bg-accent-light"
        />
      </div>
      
      {/* Task Progress and Achievements */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        {/* Task list column */}
        <div className="lg:col-span-2">
          <Card className="shadow">
            <div className="px-6 py-5 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium leading-6 text-gray-900 font-roboto">Recent Tasks</h3>
                <div className="flex items-center space-x-2">
                  <select className="pl-3 pr-10 py-2 text-sm border-gray-300 focus:outline-none focus:ring-primary focus:border-primary rounded-md">
                    <option>All Tasks</option>
                    <option>Pending</option>
                    <option>Completed</option>
                  </select>
                </div>
              </div>
            </div>
            
            {isLoadingTasks ? (
              <div className="p-6 text-center text-gray-500">Loading tasks...</div>
            ) : tasks.length === 0 ? (
              <div className="p-6 text-center text-gray-500">
                <ClipboardList className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                <p>No tasks found. Start by creating a new task.</p>
              </div>
            ) : (
              <>
                <ul className="divide-y divide-gray-200">
                  {tasks.slice(0, 4).map((task) => (
                    <TaskItem
                      key={task.id}
                      id={task.id}
                      title={task.title}
                      description={task.description}
                      status={task.status}
                      priority={task.priority}
                      dueDate={task.endDate}
                      projectName={task.project.name}
                      assignee={task.assignee}
                      onEdit={() => {}}
                    />
                  ))}
                </ul>
                
                <div className="px-6 py-4 border-t border-gray-200">
                  <Link href="/tasks">
                    <Button variant="outline" className="w-full">
                      View All Tasks
                    </Button>
                  </Link>
                </div>
              </>
            )}
          </Card>
        </div>
        
        {/* User Achievements */}
        <div className="space-y-5">
          <Leaderboard />
          <BadgeGrid />
        </div>
      </div>
      
      {/* Weekly Calendar Preview */}
      <MiniCalendar />
    </div>
  );
};

export default Dashboard;
