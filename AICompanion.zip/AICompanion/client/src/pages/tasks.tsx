import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import TaskItem from "@/components/task/TaskItem";
import TaskForm from "@/components/task/TaskForm";
import { Plus, Search, ClipboardList } from "lucide-react";

// Task interface
interface Task {
  id: number;
  title: string;
  description: string;
  status: "pending" | "in_progress" | "completed" | "delayed";
  priority: "low" | "medium" | "high";
  projectId: number;
  assigneeId: number | null;
  startDate: string;
  endDate: string;
  completedAt: string | null;
}

// Enhanced task with project and assignee info
interface EnhancedTask extends Task {
  project: {
    id: number;
    name: string;
  };
  assignee?: {
    id: number;
    fullName: string;
    avatarUrl?: string;
  };
}

// Project interface
interface Project {
  id: number;
  name: string;
}

const Tasks = () => {
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [projectFilter, setProjectFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");

  // Fetch tasks
  const { data: tasks = [], isLoading: isLoadingTasks } = useQuery<EnhancedTask[]>({
    queryKey: ['/api/tasks/recent', { limit: 100 }],
  });

  // Fetch projects
  const { data: projects = [] } = useQuery<Project[]>({
    queryKey: ['/api/projects'],
  });

  // Handle edit task
  const handleEditTask = (task: Task) => {
    setSelectedTask(task);
    setShowTaskForm(true);
  };

  // Filter tasks based on selected filters and search query
  const filteredTasks = tasks.filter(task => {
    // Status filter
    if (statusFilter !== "all" && task.status !== statusFilter) {
      return false;
    }
    
    // Project filter
    if (projectFilter !== "all" && task.projectId.toString() !== projectFilter) {
      return false;
    }
    
    // Search query
    if (searchQuery && !task.title.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-2xl font-bold text-gray-900 font-roboto">Tasks</h2>
        <div className="mt-3 sm:mt-0">
          <Button onClick={() => setShowTaskForm(true)}>
            <Plus className="mr-2 h-4 w-4" /> Add Task
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                type="text"
                placeholder="Search tasks..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-4">
              <Select
                value={projectFilter}
                onValueChange={setProjectFilter}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="All Projects" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Projects</SelectItem>
                  {projects.map(project => (
                    <SelectItem key={project.id} value={project.id.toString()}>
                      {project.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Tabs defaultValue="all" onValueChange={setStatusFilter}>
            <TabsList className="mb-6">
              <TabsTrigger value="all">All Tasks</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="in_progress">In Progress</TabsTrigger>
              <TabsTrigger value="completed">Completed</TabsTrigger>
              <TabsTrigger value="delayed">Delayed</TabsTrigger>
            </TabsList>

            <TabsContent value={statusFilter}>
              {isLoadingTasks ? (
                <div className="p-6 text-center text-gray-500">Loading tasks...</div>
              ) : filteredTasks.length === 0 ? (
                <div className="p-6 text-center text-gray-500">
                  <ClipboardList className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                  <p>No tasks found matching your filters.</p>
                  <Button 
                    variant="outline" 
                    onClick={() => {
                      setStatusFilter("all");
                      setProjectFilter("all");
                      setSearchQuery("");
                    }}
                    className="mt-4"
                  >
                    Clear filters
                  </Button>
                </div>
              ) : (
                <div className="bg-white rounded-md shadow overflow-hidden">
                  <ul className="divide-y divide-gray-200">
                    {filteredTasks.map((task) => (
                      <TaskItem
                        key={task.id}
                        id={task.id}
                        title={task.title}
                        description={task.description}
                        status={task.status}
                        priority={task.priority}
                        dueDate={task.endDate}
                        projectName={task.project.name}
                        assignee={task.assignee}
                        onEdit={() => handleEditTask(task)}
                      />
                    ))}
                  </ul>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {showTaskForm && (
        <TaskForm
          task={selectedTask}
          onClose={() => {
            setShowTaskForm(false);
            setSelectedTask(null);
          }}
        />
      )}
    </div>
  );
};

export default Tasks;
