import React from "react";

export default function TeamPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-purple-600 via-blue-500 to-indigo-400 text-transparent bg-clip-text">
          Team Tensor Titans
        </h1>
        <div className="text-xl text-gray-600 mb-6">Code: HV25-TX07</div>
        <p className="text-lg text-gray-500 max-w-2xl mx-auto">
          Shetty Institute of Technology, Gulbarga
        </p>
      </div>

      <div className="w-40 h-40 mx-auto mb-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-xl">
        <span className="text-white text-4xl font-bold">TT</span>
      </div>
      
      <div className="max-w-3xl mx-auto mb-20">
        <div className="bg-gradient-to-r from-indigo-50 to-blue-50 border-none shadow-lg overflow-hidden rounded-xl p-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">About Our Team</h2>
          <p className="text-gray-600 leading-relaxed">
            We are a talented team of engineers and computer scientists from Shetty Institute of Technology, Gulbarga. 
            Our team is working on cutting-edge solutions in task coordination, combining AI-powered prioritization with 
            an intuitive project management interface. We're committed to building tools that help service providers 
            streamline their workflows and enhance productivity.
          </p>
        </div>
      </div>

      <h2 className="text-3xl font-bold text-center mb-10">Our Team Members</h2>
      
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {[
          { name: "Mohd Zaheeruddin", role: "AI/ML Lead" },
          { name: "Shashank Anand Hadpad", role: "CS" },
          { name: "Nandini", role: "CS" },
          { name: "Nisarga", role: "CS" },
          { name: "Sanjana Ambalgi", role: "CS" }
        ].map((member, index) => (
          <div key={index} className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:scale-105">
            <div className="p-6">
              <div className="mb-4 w-20 h-20 bg-gradient-to-br from-blue-400 to-purple-500 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                {member.name.split(' ').map(n => n[0]).join('')}
              </div>
              
              <h3 className="text-xl font-bold mb-2">{member.name}</h3>
              <p className="text-indigo-600 font-medium mb-4">{member.role}</p>
              
              <div className="w-12 h-1 bg-gradient-to-r from-purple-500 to-blue-400 rounded mb-4"></div>
              
              <p className="text-gray-600">
                Working on innovative solutions to enhance task coordination and project management.
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}