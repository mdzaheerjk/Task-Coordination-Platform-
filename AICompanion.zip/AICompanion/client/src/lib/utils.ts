import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { format, isToday, isYesterday, addDays } from "date-fns";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatTaskDate(date: Date | string): string {
  const taskDate = typeof date === 'string' ? new Date(date) : date;
  
  if (isToday(taskDate)) {
    return 'Today';
  } else if (isYesterday(taskDate)) {
    return 'Yesterday';
  } else if (isWithinNextWeek(taskDate)) {
    return format(taskDate, 'EEEE'); // Day name
  } else {
    return format(taskDate, 'MMM d'); // Month day
  }
}

export function isWithinNextWeek(date: Date): boolean {
  const today = new Date();
  const oneWeekFromNow = addDays(today, 7);
  return date > today && date <= oneWeekFromNow;
}

export function getPriorityColor(priority: 'Low' | 'Medium' | 'High'): {
  bg: string;
  text: string;
  dot: string;
} {
  switch (priority) {
    case 'Low':
      return { bg: 'bg-green-100', text: 'text-green-800', dot: 'bg-green-500' };
    case 'Medium':
      return { bg: 'bg-yellow-100', text: 'text-yellow-800', dot: 'bg-yellow-500' };
    case 'High':
      return { bg: 'bg-red-100', text: 'text-red-800', dot: 'bg-red-500' };
    default:
      return { bg: 'bg-gray-100', text: 'text-gray-800', dot: 'bg-gray-500' };
  }
}

export function getStatusColor(status: 'pending' | 'in_progress' | 'completed' | 'delayed') {
  switch (status) {
    case 'pending':
      return 'bg-gray-100 text-gray-800';
    case 'in_progress':
      return 'bg-blue-100 text-blue-800';
    case 'completed':
      return 'bg-green-100 text-green-800';
    case 'delayed':
      return 'bg-red-100 text-red-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
}

export function getProjectColor(projectId: number): string {
  // Consistent colors based on project ID
  const colors = [
    'bg-green-500', // Project 1
    'bg-yellow-500', // Project 2
    'bg-red-500', // Project 3
    'bg-blue-500', // Project 4
    'bg-purple-500', // Project 5
    'bg-indigo-500', // Project 6
    'bg-pink-500', // Project 7
  ];
  
  return colors[(projectId - 1) % colors.length];
}

export function getInitials(name: string): string {
  if (!name) return '';
  
  return name
    .split(' ')
    .map(part => part.charAt(0))
    .slice(0, 2)
    .join('')
    .toUpperCase();
}

export function calculateTaskProgress(completedTasks: number, totalTasks: number): number {
  if (totalTasks === 0) return 0;
  return Math.round((completedTasks / totalTasks) * 100);
}

export function getEventColorClass(type: string): string {
  switch (type.toLowerCase()) {
    case 'meeting':
      return 'fc-event-primary';
    case 'deadline':
      return 'fc-event-danger';
    case 'review':
      return 'fc-event-secondary';
    case 'follow-up':
      return 'fc-event-accent';
    case 'draft':
      return 'fc-event-warning';
    default:
      return 'fc-event-primary';
  }
}

export function getRandomId(): string {
  return Math.random().toString(36).substring(2, 9);
}
