import { ReactNode } from "react";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: ReactNode;
  change?: {
    value: string | number;
    trend: "up" | "down" | "neutral";
  };
  footerLink?: {
    label: string;
    href: string;
  };
  className?: string;
  iconClassName?: string;
}

const StatCard = ({
  title,
  value,
  icon,
  change,
  footerLink,
  className,
  iconClassName
}: StatCardProps) => {
  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardContent className="p-5">
        <div className="flex items-center">
          <div className={cn("flex-shrink-0 rounded-md p-3", iconClassName || "bg-primary/10")}>
            {icon}
          </div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">{title}</dt>
              <dd className="flex items-center">
                <div className="text-lg font-medium text-gray-900">{value}</div>
                {change && (
                  <div className={cn(
                    "ml-2 flex items-center text-sm",
                    change.trend === "up" ? "text-green-600" : 
                    change.trend === "down" ? "text-red-600" : "text-gray-500"
                  )}>
                    {change.trend === "up" && (
                      <svg className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
                      </svg>
                    )}
                    {change.trend === "down" && (
                      <svg className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                      </svg>
                    )}
                    <span className="ml-0.5">{change.value}</span>
                  </div>
                )}
              </dd>
            </dl>
          </div>
        </div>
      </CardContent>
      
      {footerLink && (
        <CardFooter className="bg-gray-50 px-5 py-3 border-t border-gray-200">
          <div className="text-sm">
            <a href={footerLink.href} className="font-medium text-primary hover:text-primary/80">
              {footerLink.label}
            </a>
          </div>
        </CardFooter>
      )}
    </Card>
  );
};

export default StatCard;
