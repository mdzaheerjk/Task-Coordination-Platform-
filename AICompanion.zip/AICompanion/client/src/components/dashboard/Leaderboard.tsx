import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getInitials } from "@/lib/utils";
import { Trophy } from "lucide-react";

interface LeaderboardUser {
  id: number;
  fullName: string;
  username: string;
  points: number;
  avatarUrl?: string;
}

const Leaderboard = () => {
  const { data: users = [], isLoading } = useQuery<LeaderboardUser[]>({
    queryKey: ['/api/users/leaderboard'],
  });
  
  // Get medal color based on position
  const getMedalColor = (position: number) => {
    switch (position) {
      case 0: return "text-yellow-500"; // Gold
      case 1: return "text-gray-400"; // Silver
      case 2: return "text-amber-600"; // Bronze
      default: return "text-gray-500"; // Others
    }
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="px-6 py-5 border-b border-gray-200">
        <CardTitle className="text-lg font-medium">Leaderboard</CardTitle>
      </CardHeader>
      
      <CardContent className="p-0">
        {isLoading ? (
          <div className="p-6 text-center">Loading leaderboard...</div>
        ) : users.length === 0 ? (
          <div className="p-6 text-center text-gray-500">No users found</div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {users.map((user, index) => (
              <li key={user.id} className="px-6 py-3 flex items-center">
                <div className="w-6 text-center">
                  {index < 3 ? (
                    <Trophy className={`h-5 w-5 ${getMedalColor(index)}`} />
                  ) : (
                    <span className="text-sm font-medium text-gray-900">{index + 1}</span>
                  )}
                </div>
                
                <Avatar className="h-8 w-8 ml-2">
                  <AvatarImage src={user.avatarUrl} alt={user.fullName} />
                  <AvatarFallback>{getInitials(user.fullName)}</AvatarFallback>
                </Avatar>
                
                <div className="ml-3 flex-1">
                  <p className="text-sm font-medium text-gray-900">{user.fullName}</p>
                  <p className="text-xs text-gray-500">@{user.username}</p>
                </div>
                
                <div className="flex items-center">
                  <span className="bg-accent text-white px-2 py-1 rounded text-xs font-medium">
                    {user.points} pts
                  </span>
                </div>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
};

export default Leaderboard;
