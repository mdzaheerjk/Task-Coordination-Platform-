import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { format, startOfWeek, addDays, isSameDay, isWithinInterval } from "date-fns";

interface Task {
  id: number;
  title: string;
  status: string;
  priority: string;
  startDate: string;
  endDate: string;
}

const MiniCalendar = () => {
  const today = new Date();
  const startOfCurrentWeek = startOfWeek(today, { weekStartsOn: 1 }); // Monday
  
  // Generate week days
  const weekDays = useMemo(() => {
    return Array.from({ length: 7 }).map((_, i) => {
      const date = addDays(startOfCurrentWeek, i);
      return {
        date,
        dayName: format(date, 'EEE'),
        dayNumber: format(date, 'd'),
        isToday: isSameDay(date, today)
      };
    });
  }, [startOfCurrentWeek, today]);
  
  // Fetch tasks
  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ['/api/tasks/recent'],
  });
  
  // Filter tasks for current week and group by date
  const tasksByDay = useMemo(() => {
    const weekStart = startOfCurrentWeek;
    const weekEnd = addDays(weekStart, 6);
    
    return weekDays.map(day => {
      const dayTasks = tasks.filter(task => {
        const startDate = new Date(task.startDate);
        const endDate = new Date(task.endDate);
        
        return isSameDay(day.date, startDate) || 
               isSameDay(day.date, endDate) || 
               (startDate && endDate && isWithinInterval(day.date, { start: startDate, end: endDate }));
      });
      
      return {
        ...day,
        tasks: dayTasks
      };
    });
  }, [weekDays, tasks]);
  
  const getTaskColorClass = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-200 text-red-800';
      case 'medium': return 'bg-yellow-200 text-yellow-800';
      case 'low': return 'bg-green-200 text-green-800';
      default: return 'bg-gray-200 text-gray-800';
    }
  };

  return (
    <Card className="overflow-hidden shadow rounded-lg">
      <CardHeader className="px-6 py-5 border-b border-gray-200 flex items-center justify-between">
        <CardTitle className="text-lg font-medium">This Week</CardTitle>
        <Link href="/calendar">
          <Button variant="link" className="text-primary p-0 h-auto">
            View Full Calendar
          </Button>
        </Link>
      </CardHeader>
      
      <CardContent className="p-6">
        <div className="grid grid-cols-7 gap-2">
          {/* Week day headers */}
          {weekDays.map((day) => (
            <div key={day.dayName} className="text-center font-medium text-gray-500 text-xs">
              {day.dayName.toUpperCase()}
            </div>
          ))}
          
          {/* Calendar cells */}
          {tasksByDay.map((day) => (
            <div 
              key={day.date.toISOString()} 
              className={`h-24 border rounded-md p-1 overflow-hidden ${
                day.isToday 
                  ? 'bg-primary-light ring-2 ring-primary' 
                  : day.date.getDay() === 0 || day.date.getDay() === 6 
                    ? 'bg-gray-50' 
                    : 'bg-white'
              }`}
            >
              <div className={`text-xs font-medium ${day.isToday ? 'text-primary' : 'text-gray-700'}`}>
                {day.dayNumber}
              </div>
              
              <div className="mt-1 space-y-1">
                {day.tasks.slice(0, 3).map((task) => (
                  <div 
                    key={task.id} 
                    className={`px-1 py-0.5 text-xs rounded truncate ${getTaskColorClass(task.priority)}`}
                  >
                    {task.title}
                  </div>
                ))}
                
                {day.tasks.length > 3 && (
                  <div className="px-1 py-0.5 text-xs text-gray-500">
                    +{day.tasks.length - 3} more
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default MiniCalendar;
