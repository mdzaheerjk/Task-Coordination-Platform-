import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Award, Zap, CheckSquare, Users, Star, Plus,
  AlertCircle
} from "lucide-react";

interface Badge {
  id: number;
  name: string;
  description: string;
  icon: string;
  pointsRequired: number;
}

const BadgeGrid = () => {
  const { user } = useAuth();
  
  const { data: badges = [], isLoading } = useQuery<Badge[]>({
    queryKey: [`/api/users/${user?.id}/badges`],
    enabled: !!user?.id,
  });

  // Icons for badges
  const getIconComponent = (iconName: string) => {
    switch (iconName) {
      case 'award': return <Award className="h-5 w-5" />;
      case 'bolt': return <Zap className="h-5 w-5" />;
      case 'calendar-check': return <CheckSquare className="h-5 w-5" />;
      case 'users': return <Users className="h-5 w-5" />;
      case 'star': return <Star className="h-5 w-5" />;
      default: return <Award className="h-5 w-5" />;
    }
  };

  // Sample locked badges for UI
  const lockedBadges = [
    { id: 'locked-1', name: 'Team Player', icon: 'users' },
    { id: 'locked-2', name: 'Top Rated', icon: 'star' }
  ];

  return (
    <Card className="overflow-hidden">
      <CardHeader className="px-6 py-5 border-b border-gray-200">
        <CardTitle className="text-lg font-medium">Your Badges</CardTitle>
      </CardHeader>
      
      <CardContent className="p-6">
        {isLoading ? (
          <div className="text-center py-4">Loading badges...</div>
        ) : (
          <div className="grid grid-cols-3 gap-4">
            {badges.map((badge) => (
              <div key={badge.id} className="flex flex-col items-center">
                <div className="w-12 h-12 rounded-full bg-primary-light flex items-center justify-center text-primary">
                  {getIconComponent(badge.icon)}
                </div>
                <span className="mt-2 text-xs font-medium text-gray-700">{badge.name}</span>
              </div>
            ))}
            
            {/* Locked badges */}
            {lockedBadges.map((badge) => (
              <div key={badge.id} className="flex flex-col items-center">
                <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center text-gray-400">
                  {getIconComponent(badge.icon)}
                </div>
                <span className="mt-2 text-xs font-medium text-gray-700">{badge.name}</span>
              </div>
            ))}
            
            {/* Unlock more badge */}
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 border-2 border-dashed border-gray-300">
                <Plus className="h-5 w-5" />
              </div>
              <span className="mt-2 text-xs font-medium text-gray-500">Unlock More</span>
            </div>
          </div>
        )}
        
        {badges.length === 0 && !isLoading && (
          <div className="text-center py-4 text-gray-500 flex flex-col items-center">
            <AlertCircle className="h-8 w-8 mb-2 text-gray-400" />
            <p>Complete tasks to earn badges!</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default BadgeGrid;
