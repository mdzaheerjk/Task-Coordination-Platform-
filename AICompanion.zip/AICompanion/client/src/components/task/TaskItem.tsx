import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Edit, Trash2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { formatTaskDate, getPriorityColor, getInitials } from "@/lib/utils";

interface TaskItemProps {
  id: number;
  title: string;
  description?: string;
  priority: "low" | "medium" | "high";
  status: "pending" | "in_progress" | "completed" | "delayed";
  dueDate: string;
  projectName: string;
  assignee?: {
    id: number;
    fullName: string;
    avatarUrl?: string;
  };
  onEdit?: () => void;
}

const TaskItem = ({
  id,
  title,
  description,
  priority,
  status,
  dueDate,
  projectName,
  assignee,
  onEdit
}: TaskItemProps) => {
  const [isDeleting, setIsDeleting] = useState(false);
  const queryClient = useQueryClient();
  
  const isCompleted = status === "completed";
  const priorityColors = getPriorityColor(priority);
  
  // Task completion mutation
  const completeMutation = useMutation({
    mutationFn: () => apiRequest('POST', `/api/tasks/${id}/complete`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks/recent'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      queryClient.invalidateQueries({ queryKey: ['/api/users/leaderboard'] });
    }
  });

  // Task deletion mutation
  const deleteMutation = useMutation({
    mutationFn: () => apiRequest('DELETE', `/api/tasks/${id}`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks/recent'] });
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
      setIsDeleting(false);
    }
  });

  const handleStatusChange = () => {
    if (!isCompleted) {
      completeMutation.mutate();
    }
  };

  const handleDelete = () => {
    deleteMutation.mutate();
  };

  return (
    <li className="px-6 py-4 flex items-center">
      <div className="flex-shrink-0">
        <Checkbox 
          id={`task-${id}`} 
          checked={isCompleted}
          onCheckedChange={handleStatusChange}
          disabled={completeMutation.isPending}
        />
      </div>
      
      <div className="ml-3 flex-1">
        <div className="flex items-center justify-between">
          <p className={`text-sm font-medium ${
            isCompleted ? 'line-through text-gray-500' : 'text-gray-900'
          }`}>
            {title}
          </p>
          
          <div className="flex flex-shrink-0 space-x-2">
            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
              priorityColors.bg
            } ${priorityColors.text}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${priorityColors.dot} mr-1.5`}></span>
              {priority.charAt(0).toUpperCase() + priority.slice(1)} Priority
            </span>
            
            <span className="text-sm text-gray-500">
              {formatTaskDate(dueDate)}
            </span>
          </div>
        </div>
        
        <div className="mt-1 flex items-center justify-between">
          <div className="flex items-center">
            {assignee ? (
              <Avatar className="h-6 w-6">
                <AvatarImage src={assignee.avatarUrl} alt={assignee.fullName} />
                <AvatarFallback>{getInitials(assignee.fullName)}</AvatarFallback>
              </Avatar>
            ) : (
              <div className="h-6 w-6 rounded-full bg-gray-200 flex items-center justify-center">
                <span className="text-xs text-gray-500">?</span>
              </div>
            )}
            <span className="ml-2 text-sm text-gray-500">{projectName}</span>
          </div>
          
          <div className="flex space-x-2">
            {onEdit && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={onEdit} 
                className="h-8 w-8"
              >
                <Edit className="h-4 w-4 text-gray-500" />
              </Button>
            )}
            
            <AlertDialog open={isDeleting} onOpenChange={setIsDeleting}>
              <AlertDialogTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8"
                >
                  <Trash2 className="h-4 w-4 text-gray-500" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete Task</AlertDialogTitle>
                  <AlertDialogDescription>
                    Are you sure you want to delete this task? This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel disabled={deleteMutation.isPending}>Cancel</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={handleDelete} 
                    disabled={deleteMutation.isPending}
                    className="bg-red-500 hover:bg-red-600"
                  >
                    {deleteMutation.isPending ? "Deleting..." : "Delete"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </div>
    </li>
  );
};

export default TaskItem;
