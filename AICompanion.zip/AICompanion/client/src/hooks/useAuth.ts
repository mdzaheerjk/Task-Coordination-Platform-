import { useAuth as useAuthContext } from '@/contexts/AuthContext';

// This hook is a simple wrapper around the context
// to make it easier to import in components
export const useAuth = () => {
  return useAuthContext();
};
